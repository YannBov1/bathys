"""The numbers the prose quotes must still be the numbers the code gives.

README.md, DATA.md and the examples all state figures: a factor of 3.8 here, 46
percent there. Those were computed once. Nothing has been stopping them from
drifting away from what the package now returns, and a reader has no way to
tell when they have.

Each test below recomputes one quoted figure. When one fails, the prose is
what needs fixing, not the test — unless the change to the code was a mistake,
in which case it is the other way round and the test has done its job.
"""

from __future__ import annotations

import math
import pathlib
import re
import warnings

import numpy as np
import pytest

import jerlov
from jerlov import _data

ROOT = pathlib.Path(__file__).resolve().parent.parent
source_tree = pytest.mark.skipif(
    not (ROOT / "README.md").exists(),
    reason="not running from a source tree",
)


def quiet():
    return warnings.catch_warnings()


# -- the sources disagree, and by how much --------------------------------


def test_scattering_at_510nm_differs_by_the_stated_factor():
    """README and sources_disagree.py both say 3.8 for Jerlov III."""
    with quiet():
        warnings.simplefilter("ignore")
        measured = float(jerlov.water("III").b(510))
        inverted = float(jerlov.water("III", source="solonenko2015").b(510))
    assert inverted / measured == pytest.approx(3.8, abs=0.05)


def test_the_disagreement_does_not_run_one_way():
    """sources_disagree.py claims Jerlov IB goes the other direction."""
    with quiet():
        warnings.simplefilter("ignore")
        measured = float(jerlov.water("IB").b(510))
        inverted = float(jerlov.water("IB", source="solonenko2015").b(510))
    assert inverted / measured < 0.5


def test_the_three_routes_span_the_stated_factor_at_532nm():
    """DATA.md section 17 says 5.1 for Jerlov III."""
    chlorophyll_model = 1.8998          # Abd El-Mottaleb et al. (2024)
    with quiet():
        warnings.simplefilter("ignore")
        measured = float(jerlov.water("III").c(532))
        inverted = float(jerlov.water("III", source="solonenko2015").c(532))
    assert measured == pytest.approx(0.371, abs=0.001)
    assert inverted == pytest.approx(1.092, abs=0.001)
    assert chlorophyll_model / measured == pytest.approx(5.1, abs=0.05)


# -- the scattering model constants ---------------------------------------


def test_the_small_particle_coefficients_differ_by_the_stated_amount():
    """DATA.md section 6: 1.513 is 31 percent larger than 1.151302."""
    haltrin = jerlov.get_source("williamson2022").scattering.small_coeff
    solonenko = jerlov.get_source("solonenko2015").scattering.small_coeff
    assert haltrin == pytest.approx(1.151302)
    assert solonenko == pytest.approx(1.513)
    assert solonenko / haltrin - 1 == pytest.approx(0.31, abs=0.005)


# -- shortwave penetration ------------------------------------------------


def test_the_shortwave_fit_misses_its_source_by_the_stated_amount():
    """README, DATA.md section 14 and solar_heating.py all say 46 percent."""
    rows = _data._rows("jerlov1968_total_irradiance.csv")
    worst = 0.0
    for row in rows:
        if row["water_type"] not in ("I", "IA", "IB", "II", "III"):
            continue
        if not row["percent_of_surface"]:
            continue
        depth = float(row["depth_m"])
        if depth == 0 or depth > 100:
            continue
        want = float(row["percent_of_surface"]) / 100
        got = jerlov.solar_fraction(row["water_type"], depth)
        worst = max(worst, abs(got - want) / want)
    assert worst == pytest.approx(0.46, abs=0.01)


def test_the_published_R_values_are_what_the_docs_print():
    published = {"I": 0.58, "IA": 0.62, "IB": 0.67, "II": 0.77, "III": 0.78}
    for water_type, value in published.items():
        assert jerlov.shortwave_parameters(water_type).R == pytest.approx(value)


# -- backscattering -------------------------------------------------------


def test_the_worst_chi_p_spread_is_the_stated_figure():
    """README and DATA.md section 18 both say 34.8 percent at 170 degrees."""
    with pytest.warns(jerlov.AngleWarning, match="34.8"):
        result = jerlov.bb_from_vsf(0.002, 170.0, 532.0)
    assert result.quoted_error_percent == pytest.approx(34.8)
    middle = [jerlov.bb_from_vsf(0.002, a, 532.0).quoted_error_percent
              for a in (100.0, 120.0, 140.0, 160.0)]
    assert max(middle) <= 6.5, "the 3-6 percent claim no longer holds"


def test_chi_w_and_chi_p_cross_where_the_docs_say():
    """DATA.md section 18 quotes 116.9 degrees against the paper's ~118."""
    r = (1 - jerlov.backscattering.DEPOLARISATION_RATIO) / (
        1 + jerlov.backscattering.DEPOLARISATION_RATIO)
    angles = np.linspace(90.0, 170.0, 80001)
    gap = [(1 + r / 3) / (1 + r * math.cos(math.radians(a)) ** 2)
           - jerlov.particulate_chi(a) for a in angles]
    crossing = float(angles[int(np.argmin(np.abs(gap)))])
    assert crossing == pytest.approx(116.9, abs=0.1)


# -- the example that argues against defaults -----------------------------


def test_the_guess_overstates_contrast_by_the_stated_amount():
    """from_one_measurement.py computes 65 percent and the prose repeats it.

    The example computes this rather than hard-coding it, so this test is
    what stops the *prose* around it from going stale.
    """
    wl = np.arange(420.0, 681.0, 20.0)
    a = 0.02 + 0.35 * np.exp(-(wl - 420.0) / 90.0) + 0.30 * (wl > 600)
    b = 0.45 * (550.0 / wl) ** 0.8
    water = jerlov.Water.from_measurements(wl, a=a, b=b)

    measured = jerlov.bb_from_vsf(0.0021, 140.0, 532.0, salinity_psu=35.0)
    ratio = measured.bb / water.b(532.0)
    assert ratio == pytest.approx(0.033, abs=0.001)

    surface = np.interp(wl, *jerlov.d65(), left=0.0, right=0.0)
    with quiet():
        warnings.simplefilter("ignore")
        scene = jerlov.Scene.at_depth(
            water, 8.0, surface, wl,
            kd=jerlov.water("II", source="austin1986"))
        white = scene.downwelling / np.pi
        contrasts = {}
        for label, value in (("guess", 0.015), ("measured", ratio)):
            b_inf = jerlov.veiling_radiance_estimate(
                water, scene.downwelling, wl, backscatter_ratio=value)
            observed = scene.observe(np.full_like(wl, 0.5), 5.0,
                                     veiling_radiance=b_inf)
            contrasts[label] = float(
                np.mean(np.abs(observed.contrast(0.1 * white))))
    overstatement = contrasts["guess"] / contrasts["measured"] - 1
    assert overstatement == pytest.approx(0.65, abs=0.03)


# -- the prose and the code are checked against each other ----------------


@source_tree
def test_the_readme_quotes_a_transmittance_the_package_produces():
    """`solar_fraction("IB", 10.0)` appears in the README with its answer."""
    readme = (ROOT / "README.md").read_text()
    match = re.search(
        r'solar_fraction\("IB", 10\.0\).*?#\s*([\d.]+)', readme)
    assert match, "the README no longer shows that call with its result"
    assert jerlov.solar_fraction("IB", 10.0) == pytest.approx(
        float(match.group(1)), abs=0.0005)


@source_tree
def test_the_readme_quotes_a_chi_p_the_package_produces():
    readme = (ROOT / "README.md").read_text()
    match = re.search(r"r\.chi_p, r\.quoted_error_percent\s*#\s*([\d.]+),\s*([\d.]+)",
                      readme)
    assert match, "the README no longer shows chi_p with its value"
    result = jerlov.bb_from_vsf(0.0021, 140.0, 532.0)
    assert result.chi_p == pytest.approx(float(match.group(1)))
    assert result.quoted_error_percent == pytest.approx(float(match.group(2)))
