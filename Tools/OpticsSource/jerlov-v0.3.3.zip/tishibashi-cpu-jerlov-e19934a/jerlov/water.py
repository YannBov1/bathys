"""Inherent optical properties of a body of water.

Named Jerlov water types are only an entry point: they are turned into a
:class:`Water` immediately, and every calculation works on the resulting
spectra. Measured coefficients can be supplied directly and take exactly the
same path.
"""

from __future__ import annotations

import warnings

import numpy as np

from . import _data
from .sources import Source, get_source


class ProvenanceWarning(UserWarning):
    """Raised when a returned value rests on something the caller should know.

    Interpolating across a wavelength that a published table got wrong, or
    that was itself extrapolated, gives a number that looks no different from
    a sound one. This warning is the only thing that distinguishes them.
    """


class MissingQuantityError(LookupError):
    """Raised when a quantity is not determined by the available data."""


def _as_array(x) -> np.ndarray:
    return np.atleast_1d(np.asarray(x, dtype=float))


def _like_input(result: np.ndarray, original) -> np.ndarray | float:
    """Return a float for scalar input, an array otherwise.

    This is what ``numpy.interp`` does. Returning a one-element array for a
    scalar wavelength invites ``float(w.a(550))``, which numpy 2 refuses.
    """
    if np.ndim(original) == 0:
        return float(result[0])
    return result


def _support(grid: np.ndarray, query: np.ndarray) -> list[tuple[int, ...]]:
    """The indices of the samples of ``grid`` each query's answer rests on.

    A query that lands exactly on a sample rests on that sample alone: it is
    not interpolated, so its neighbours are no part of the answer. Otherwise
    it rests on the samples either side. The NaN check and the provenance
    warnings all use this, so that they cannot disagree about what a value
    depends on.
    """
    n = grid.size
    out: list[tuple[int, ...]] = []
    for i, w_query in zip(np.searchsorted(grid, query), query):
        if i < n and grid[i] == w_query:
            out.append((int(i),))
        else:
            out.append((max(int(i) - 1, 0), min(int(i), n - 1)))
    return out


class Water:
    """Absorption and scattering coefficients as functions of wavelength.

    Parameters
    ----------
    wavelengths:
        Wavelengths in nm, ascending.
    a, b:
        Absorption and scattering coefficients in 1/m. Use ``nan`` for
        wavelengths where the value is unknown.
    kd:
        Downwelling diffuse attenuation coefficient in 1/m, if known.
    name:
        Jerlov water type, when the object came from one.
    source:
        The :class:`~jerlov.sources.Source` the coefficients came from.
    flags:
        Per-wavelength status strings, parallel to ``wavelengths``.
    """

    def __init__(
        self,
        wavelengths,
        a=None,
        b=None,
        *,
        kd=None,
        name: str | None = None,
        source: Source | None = None,
        flags: dict[str, tuple[str, ...]] | None = None,
    ) -> None:
        # Copied, so that neither the caller's arrays nor the packaged tables
        # can change underneath this object, and it cannot change them.
        self.wavelengths = np.array(wavelengths, dtype=float)
        if self.wavelengths.ndim != 1 or self.wavelengths.size == 0:
            raise ValueError("wavelengths must be a non-empty 1-D array")
        if np.any(np.diff(self.wavelengths) <= 0):
            raise ValueError("wavelengths must be strictly ascending")

        self._series: dict[str, np.ndarray] = {}
        for key, value in (("a", a), ("b", b), ("Kd", kd)):
            if value is None:
                continue
            arr = np.array(value, dtype=float)
            if arr.shape != self.wavelengths.shape:
                raise ValueError(f"{key} must have the same shape as wavelengths")
            self._series[key] = arr
        if not self._series:
            raise ValueError("at least one of a, b, kd must be given")

        self.name = name
        self.source = source
        self._flags = flags or {}

    # -- construction ----------------------------------------------------

    @classmethod
    def from_measurements(cls, wavelengths, a=None, b=None, *, kd=None,
                          name: str | None = None) -> "Water":
        """Build a :class:`Water` from the caller's own measurements."""
        return cls(wavelengths, a=a, b=b, kd=kd, name=name, source=None)

    # -- access ----------------------------------------------------------

    @property
    def range_nm(self) -> tuple[float, float]:
        return float(self.wavelengths[0]), float(self.wavelengths[-1])

    def has(self, quantity: str) -> bool:
        return quantity in self._series

    def _interp(self, quantity: str, wl) -> np.ndarray:
        if quantity not in self._series:
            available = ", ".join(sorted(self._series)) or "none"
            raise MissingQuantityError(
                f"{quantity!r} is not available for this water "
                f"(available: {available})"
            )
        query = _as_array(wl)
        lo, hi = self.range_nm
        if np.any(query < lo) or np.any(query > hi):
            raise ValueError(
                f"wavelength outside the range of the data ({lo:g}-{hi:g} nm). "
                "This package does not extrapolate."
            )
        support = _support(self.wavelengths, query)
        self._warn_if_flagged(quantity, support)
        values = self._series[quantity]
        out = np.interp(query, self.wavelengths, values)
        # np.interp happily bridges a NaN-free path around a NaN, so check the
        # samples the answer actually rests on.
        for k, samples in enumerate(support):
            if any(np.isnan(values[j]) for j in samples):
                out[k] = np.nan
        return _like_input(out, wl)

    def _warn_if_flagged(self, quantity: str,
                         support: list[tuple[int, ...]]) -> None:
        statuses = self._flags.get(quantity)
        if not statuses:
            return
        hit: set[str] = set()
        for samples in support:
            for j in samples:
                status = statuses[j]
                if status in _data.QUESTIONABLE:
                    hit.add(f"{status} at {self.wavelengths[j]:g} nm")
        if hit:
            warnings.warn(
                f"{quantity} for Jerlov {self.name} rests on flagged values: "
                + "; ".join(sorted(hit))
                + ". See DATA.md for what is known about them.",
                ProvenanceWarning,
                stacklevel=_data.caller_stacklevel(),
            )

    def a(self, wl):
        """Absorption coefficient in 1/m."""
        return self._interp("a", wl)

    def b(self, wl):
        """Scattering coefficient in 1/m."""
        return self._interp("b", wl)

    def c(self, wl):
        """Beam attenuation coefficient ``a + b`` in 1/m."""
        return self.a(wl) + self.b(wl)

    def kd(self, wl):
        """Downwelling diffuse attenuation coefficient in 1/m."""
        return self._interp("Kd", wl)

    def bb(self, wl, *, backscatter_ratio: float | None = None):
        """Backscattering coefficient in 1/m.

        ``backscatter_ratio`` is bb/b and has no default. It is not determined
        by the Jerlov classification: deriving it from the particle
        concentrations of Solonenko & Mobley and of Williamson & Hollins gives
        answers that differ by up to a factor of 31. See DATA.md section 10.

        Reported ranges are roughly 0.005-0.01 for open ocean and 0.015-0.03
        for coastal water; the Petzold average-particle phase function gives
        about 0.0183.
        """
        if backscatter_ratio is None:
            raise MissingQuantityError(
                "bb is not determined by the water type. Pass "
                "backscatter_ratio=... explicitly (bb/b; roughly 0.005-0.01 "
                "for open ocean, 0.015-0.03 for coastal water). "
                "See DATA.md section 10."
            )
        if not 0.0 < backscatter_ratio < 0.5:
            raise ValueError("backscatter_ratio must lie in (0, 0.5)")
        return self.b(wl) * backscatter_ratio

    # -- description -----------------------------------------------------

    def caveats(self) -> tuple[str, ...]:
        """Return what is known to be doubtful about this water's data."""
        out: list[str] = []
        if self.source is not None:
            out.extend(self.source.caveats)
        for quantity, statuses in self._flags.items():
            flagged = {s for s in statuses if s in _data.QUESTIONABLE}
            for status in sorted(flagged):
                count = sum(1 for s in statuses if s == status)
                out.append(f"{quantity}: {count} wavelength(s) marked {status!r}")
        return tuple(out)

    def __repr__(self) -> str:  # pragma: no cover - convenience only
        lo, hi = self.range_nm
        src = self.source.key if self.source else "user"
        return (
            f"<Water {self.name or 'unnamed'} source={src} "
            f"{lo:g}-{hi:g} nm, {', '.join(sorted(self._series))}>"
        )


# -- factories -----------------------------------------------------------

_IOP_FILES = {
    "williamson2022": ("williamson2022_iop.csv", ("a", "b")),
    "solonenko2015": ("solonenko2015_iop.csv", ("a", "b", "Kd")),
}

_KD_FILES = {
    "jerlov1976": ("jerlov1976_kd.csv", "Kd_downwelling_per_m"),
    "austin1986": ("austin1986_kd.csv", "Kd_downwelling_per_m"),
}


def water(water_type: str, source: str = "williamson2022") -> Water:
    """Return the :class:`Water` for a named Jerlov type.

    The default source is Williamson & Hollins (2022) because it is the only
    published set in which a and b rest on measurements rather than on an
    inversion of Kd.
    """
    src = get_source(source)
    if water_type not in src.water_types:
        available = ", ".join(src.water_types)
        raise KeyError(
            f"source {source!r} does not cover Jerlov {water_type!r} "
            f"(available: {available})"
        )

    if source in _IOP_FILES:
        filename, quantities = _IOP_FILES[source]
        series: dict[str, np.ndarray] = {}
        flags: dict[str, tuple[str, ...]] = {}
        wavelengths = None
        for quantity in quantities:
            wl, values, statuses = _data.spectrum(
                filename, water_type, quantity, "value_per_m"
            )
            if wavelengths is None:
                wavelengths = wl
            elif not np.array_equal(wavelengths, wl):
                raise RuntimeError(f"inconsistent wavelength grid in {filename}")
            series[quantity] = values
            flags[quantity] = statuses
        return Water(
            wavelengths,
            a=series.get("a"),
            b=series.get("b"),
            kd=series.get("Kd"),
            name=water_type,
            source=src,
            flags=flags,
        )

    filename, column = _KD_FILES[source]
    wl, values, statuses = _data.spectrum(filename, water_type, None, column)
    return Water(
        wl, kd=values, name=water_type, source=src, flags={"Kd": statuses}
    )


def water_type_at_depth(surface_water_type: str, depth_m: float) -> str | None:
    """The Jerlov type that typically applies at ``depth_m``.

    The classification is defined on the top 10 m, but clarity changes with
    depth: water that is Jerlov I at the surface is typically IB below about
    40 m, and turbid coastal water typically clears with depth. Williamson &
    Hollins (2023) derived these profiles from more than 2500 measurement
    campaigns.

    Returns ``None`` where the paper declined to declare a type, which is
    wherever fewer than ten campaigns supported one. Coastal types run out
    quickly: 3C is declared only to 70 m, and 9C not at all below 10 m.

    This is a lookup, not a correction applied on your behalf. To use it::

        deeper = jerlov.water_type_at_depth("I", 60.0)      # "IB"
        w = jerlov.water(deeper) if deeper else jerlov.water("I")

    Notes
    -----
    The profile is what was *typical* across the campaigns, not what holds at
    any particular place or season. The paper says so explicitly, and gives
    per-cell cruise and month counts for anyone who needs to judge that.
    """
    if depth_m < 0:
        raise ValueError("depth_m cannot be negative")
    rows = _data._rows("williamson2023_depth.csv")
    known = {r["surface_water_type"] for r in rows}
    if surface_water_type not in known:
        raise KeyError(
            f"unknown water type {surface_water_type!r} "
            f"(known: {', '.join(sorted(known))})"
        )
    for row in rows:
        if row["surface_water_type"] != surface_water_type:
            continue
        if float(row["depth_min_m"]) <= depth_m < float(row["depth_max_m"]):
            return row["water_type"] or None
    # Beyond 200 m the paper makes no statement at all.
    return None


#: Austin & Petzold (1986) state their model holds below this K(490), 1/m.
AUSTIN_KD490_LIMIT = 0.16


def kd_spectrum(kd, wavelength_nm: float, at):
    """Reconstruct a Kd spectrum from a single measured value.

    Uses the model of Austin & Petzold (1986), Eq. (6)::

        K(l2) = [M(l2)/M(l1)] * [K(l1) - Kw(l1)] + Kw(l2)

    Parameters
    ----------
    kd:
        Measured Kd in 1/m. A scalar, or an array of measurements all made at
        ``wavelength_nm`` (several stations, say); each is reconstructed
        separately.
    wavelength_nm:
        Wavelength at which ``kd`` was measured. A single value.
    at:
        Wavelength(s) at which to evaluate the spectrum.

    Returns
    -------
    A float for scalar ``kd`` and ``at``. Otherwise an array of shape
    ``kd.shape + at.shape``: one spectrum per measurement.

    Notes
    -----
    The authors state the model holds for K(490) < 0.16 1/m, and a
    :class:`ProvenanceWarning` is raised for any measurement whose K(490),
    measured or implied by the model, is not below that. Accuracy is about
    8 percent at wavelengths up to 590 nm and degrades to about 31 percent at
    670 nm. M below 365 nm is itself extrapolated, and a result that rests on
    it also warns.
    """
    wl, m, kw = _data.austin_model()
    lo, hi = float(wl[0]), float(wl[-1])
    if np.ndim(wavelength_nm) != 0:
        raise ValueError(
            "wavelength_nm must be a single wavelength; for measurements at "
            "different wavelengths, call kd_spectrum once for each"
        )
    wavelength_nm = float(wavelength_nm)
    query = _as_array(at)
    for value, label in ((wavelength_nm, "wavelength_nm"), (query, "at")):
        if np.any(np.asarray(value) < lo) or np.any(np.asarray(value) > hi):
            raise ValueError(f"{label} outside the model range ({lo:g}-{hi:g} nm)")
    kd_values = np.asarray(kd, dtype=float)

    m1 = float(np.interp(wavelength_nm, wl, m))
    kw1 = float(np.interp(wavelength_nm, wl, kw))
    below = kd_values < kw1
    if np.any(below):
        shown = ", ".join(f"{v:g}" for v in np.atleast_1d(kd_values)[
            np.atleast_1d(below)][:5])
        warnings.warn(
            f"Kd={shown} is below the pure sea water value {kw1:g} at "
            f"{wavelength_nm:g} nm, which is not physically possible. "
            "Austin & Petzold (1986) reported exactly this problem in "
            "Jerlov's own type I values.",
            ProvenanceWarning,
            stacklevel=_data.caller_stacklevel(),
        )

    kd490 = (float(np.interp(490.0, wl, m)) / m1 * (kd_values - kw1)
             + float(np.interp(490.0, wl, kw)))
    outside = kd490 >= AUSTIN_KD490_LIMIT
    if np.any(outside):
        shown = ", ".join(f"{v:.3g}" for v in np.atleast_1d(kd490)[
            np.atleast_1d(outside)][:5])
        warnings.warn(
            f"K(490) = {shown} 1/m"
            + (" (implied by the model)" if wavelength_nm != 490.0 else "")
            + f" is not below {AUSTIN_KD490_LIMIT:g} 1/m, the limit Austin & "
            "Petzold (1986) give for their model. The reconstruction is "
            "outside the range it was fitted to.",
            ProvenanceWarning,
            stacklevel=_data.caller_stacklevel(),
        )

    statuses = _data.austin_model_status()
    flagged: set[str] = set()
    for samples in _support(wl, np.concatenate(([wavelength_nm], query))):
        for j in samples:
            if statuses[j] in _data.QUESTIONABLE:
                flagged.add(f"{statuses[j]} at {wl[j]:g} nm")
    if flagged:
        warnings.warn(
            "the result rests on values of M that Austin & Petzold (1986) "
            "flag as " + "; ".join(sorted(flagged)) + ", and say should be "
            "used with caution",
            ProvenanceWarning,
            stacklevel=_data.caller_stacklevel(),
        )

    ratio = np.interp(query, wl, m) / m1
    result = (ratio * (kd_values[..., None] - kw1)
              + np.interp(query, wl, kw))
    if np.ndim(at) == 0:
        result = result[..., 0]
    if np.ndim(result) == 0:
        return float(result)
    return result


def b_from_c(c, wavelength_nm, *, bw, cw, bound: str = "average"):
    """Estimate the scattering coefficient from the beam attenuation.

    Uses the measured ratios of Smart (2007) Table 1::

        b = (c - cw) * ratio + bw

    ``bound`` selects ``"average"``, ``"min"`` or ``"max"``. Smart recommends
    the upper bound for turbid water (c at 488 nm above 1.0 1/m) and the lower
    bound for clear water; the average is accurate to about 10 percent.
    Ratios are lower than tabulated in CDOM-rich water below about 488 nm.
    """
    wl, ratios = _data.b_from_c_ratio()
    if bound not in ratios:
        raise ValueError(f"bound must be one of {sorted(ratios)}")
    query = _as_array(wavelength_nm)
    if np.any(query < wl[0]) or np.any(query > wl[-1]):
        raise ValueError(
            f"wavelength outside the measured range ({wl[0]:g}-{wl[-1]:g} nm)"
        )
    ratio = np.interp(query, wl, ratios[bound])
    if np.ndim(wavelength_nm) == 0:
        ratio = ratio[0]
    result = (np.asarray(c, dtype=float) - cw) * ratio + bw
    # c and the wavelength broadcast against each other; the answer is a
    # float only when neither of them was an array.
    if np.ndim(result) == 0:
        return float(result)
    return result
